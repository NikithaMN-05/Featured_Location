module.exports = {
  outDir: "../../vuese-featuredlocation-doc",
};
