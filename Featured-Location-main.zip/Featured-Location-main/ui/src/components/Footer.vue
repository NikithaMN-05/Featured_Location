<template>
  <div class="container text-center">
    <div class="row g-0">
      <div class="col-3">
        <a
          class="link"
          href="https://github.com/pramod096/Featured-Location"
          target="_blank"
          >Source</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://github.com/pramod096/Proposal-4B/blob/main/Proposal.md"
          target="_blank"
        >
          Proposal</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://pramod096.github.io/vuese-featuredlocation-doc/#/"
          target="_blank"
          >Documentation</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://github.com/pramod096/Featured-Location/wiki"
          target="_blank"
          >Wiki</a
        >
      </div>
    </div>

    <div class="row g-0">
      <div class="col-3">
        <a
          class="link"
          href="https://github.com/pramod096/swagger-featuredlocation-doc"
          target="_blank"
          >Swagger</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://www.codacy.com/gh/pramod096/Featured-Location/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=pramod096/Featured-Location&amp;utm_campaign=Badge_Grade"
          target="_blank"
          >Codacy</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://snyk.io/test/github/pramod096/Featured-Location"
          target="_blank"
        >
          Snyk</a
        >
      </div>
      <div class="col-3">
        <a
          class="link"
          href="https://github.com/pramod096/jest-testcoverage-featuredlocation"
          target="_blank"
        >
          Code Coverage</a
        >
      </div>
    </div>
  </div>
</template>

<style scoped>
.col-3 {
  font-size: 0.65rem;
  font-family: Luminari, fantasy;
  text-shadow: 9px 9px 16px rgb(163, 177, 198, 0.6),
    -9px -9px 16px rgba(255, 255, 255, 0.5);
  text-align: center;
}

.link {
  text-decoration: none;
  color: #363233;
}

.link:hover {
  color: #007bff;
}

.container {
  padding: 2%;
  text-align: center;
}
</style>
